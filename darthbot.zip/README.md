# darthbot

Simple discord bot, integrating OpenAI Api
